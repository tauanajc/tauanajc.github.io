#R Working Group
#Lecture and Tutorial 2
#May 6, 2020
#Functions, loops, and if/else statements
#Lee Dietterich

#Remember everything in a line after the # sign is comments that will not be run.
#Look in these comments for practice exercises for the tutorial, which will be marked #Practice 

#Always begin by setting the working directory (the folder on your computer where R will read and write data files)
#I like to start by asking R for the current working directory to remind me of the correct formatting
getwd()

#Now set the desired working directory.  Your code will look different from mine here.
setwd("/Users/leedietterich/Dropbox/STRI R course/Lecture 20200506 LD")
#Practice: set your own working directory


#Read in a data table.  This is an abbreviated dataset from Dietterich et al. 2017 Ecological Applications.  In brief, I collected leaves, roots, and soils from many individuals of five plant species growing throughout a site contaminated with zinc, lead, and cadmium.  I sought to understand the relationships between soil metal concentrations, root colonization by arbuscular mycorrhizal fungi (AMF), and leaf metal concentrations.  The provided dataset gives AMF colonization (percent of root length colonized), and pollutant concentrations of leaves and soils in mg/kg.
mydata <- read.csv("Dietterich et al 2017 data for R course.csv")

#Use the structure command to make sure R is interpreting the data frame correctly
str(mydata)

#Convert the Species column to a factor
mydata$Species <- as.factor(mydata$Species)

#Convert the AMF column from proportion to percent
mydata$AMF <- mydata$AMF*100

#Let's make a table of the averages ± standard errors of AMF colonization and all of the metal concentrations for each species.

#Recall how the mean function works, and experiment with how it handles NA values (we'll see why soon).
#Make two vectors which are identical except that one has a couple NA values.
x.test <- 1:10
x.test.with.nas <- c(1:3, NA, NA, 4:8, NA, 9, 10)

#Test the mean function on both of them
mean(x.test)
mean(x.test.with.nas)

#Two ways of removing NA values before calculating the mean.
#First, using the na.rm argument within the mean function
mean(x.test.with.nas, na.rm=T)

#Second, using the na.omit function
na.omit(x.test.with.nas)
mean(na.omit(x.test.with.nas))

#The aggregate function is very useful for doing calculations on multiple treatment groups at once. 
#As an example, we'll calculate the average AMF colonization of each species in the experiment.
agg.amf <- with(mydata, aggregate(AMF, by=list(Species), FUN=mean))
agg.amf

#This returns all NA values because the mean function's default does not handle NAs the way we want.  

#We'll need to write a function that calculates averages but omits NA values.  
#First, an introduction to function notation.
xplustwo <- function(x) x+2

#For simple functions like this, the curly brackets are optional, but you will need them for more complicated functions so I will use them consistently.
xcubed <- function(x) {
  x^3
}

xplustwo(5)
xcubed(8)
x.test
xplustwo(x.test)
xcubed(x.test)

#Now, the function we want to calculate the average of all NA values in a vector x.
avg <- function(x) {
  mean(na.omit(x))
}

#While we're at it, let's write a similar function to calculate standard error.  Recall that the standard error of a vector is the standard deviation divided by the square root of the sample size.
se <- function(x) {
  sd(na.omit(x))/sqrt(length(na.omit(x)))
}

#For more complicated functions, it can be helpful to define variables inside the function. Here's another way of writing the se function above.
se2 <- function(x) {
	y <- na.omit(x)
	return(sd(y)/sqrt(length(y)))
}

#Let's test these functions on the same vector, with and without NA values, and make sure they give the same answer.
x.test <- 1:10
x.test.with.nas <- c(1:3, NA, NA, 4:8, NA, 9, 10)

mean(x.test)
avg(x.test)
mean(x.test.with.nas)
avg(x.test.with.nas)

sd(x.test)/sqrt(length(x.test))
se(x.test)
se2(x.test)
sd(x.test.with.nas)/sqrt(length(x.test.with.nas))
se(x.test.with.nas)
se2(x.test.with.nas)

#Practice: write a function takes the average of a vector of numbers without using the mean function.  Check that it works.  Bonus if it works on vectors with NA values too!


#Practice: write a function that takes the log+1 transform of a vector of numbers.  That is, for each number in the vector, add one and then take the logarithm, base 10.  Check that it works.  Bonus if it works on vectors with NA values too!



#Let's get back to the table we started in line 31. 

#We'll start with just AMF colonization as an example. 
agg.amf2 <- with(mydata, aggregate(AMF, by=list(Species), FUN=avg))
agg.amf2
#Notice that aggregate doesn't preserve column names.  Let's correct that.
names(agg.amf2) <- c("Species", "Average AMF colonization")
agg.amf2

#We can make our table much more efficiently by using aggregate on many columns at once.
#Look at the column names of mydata to see which column numbers we want to aggregate
names(mydata)
#Run the aggregate
agg.avg <- with(mydata, aggregate(mydata[,3:9], by=list(Species), FUN=avg))
#Look at the results
agg.avg
#Here only the first column needs to be renamed
names(agg.avg)[1] <- "Species"
agg.avg

#Generate standard errors by the same technique
agg.se <- with(mydata, aggregate(mydata[,3:9], by=list(Species), FUN=se))
names(agg.se)[1] <- "Species"
agg.se

#Let's round all of the entries in both of these dataframes to three significant figures to make the table look pretty.
?round
#Test the signif command on one column
round.test1 <- signif(agg.avg$AMF, 3)
round.test1
#Can signif handle multiple columns at once?
round.test2 <- signif(agg.avg[,2:8], 3)
round.test2
#Yes it can!
#Make a table of all of our pretty averages
round.avg <- with(agg.avg, cbind(Species, signif(agg.avg[,2:8], 3)))
round.avg
#Make a table of pretty SEs by the same technique
round.se <- with(agg.avg, cbind(Species, signif(agg.se[,2:8], 3)))
round.se

#To finish our table, we want each cell of columns 2 through 8 to display our rounded average, the character ±, and then our rounded SE.  We will use a technique called a "for loop" to do this one cell at a time.

#Here is a simple for loop to demonstrate the technique.  
for(ii in 1:10){
  print(ii^2)
}

#It can be convenient to embed loops inside functions.  As an example, we'll calculate the sum of squared deviations from a sample average.  That is, for a vector x, we will find the average, calculate the difference of each element of x from that average, square that difference, and sum those differences for all elements of x.

sum.of.squares <- function(x){
	#Make an empty vector of the correct length where we will fill in our values
	sq.diffs <- rep(NA, length(x))
	for(ii in 1:length(x)){
		#Define each element of sq.diffs as the squared difference we want
		sq.diffs[ii] <- (x[ii]-mean(x))^2
		}
	#Return the sum of the entries in sq.diffs
	return(sum(sq.diffs))
}

#Test this function
x.test
sum.of.squares(x.test)

#Note that this function can also be done without a for loop.
sum((x.test-mean(x.test))^2)

#Let's get back to our table. We'll start with an empty destination table again as we did with the sum of squares function, but we'll leave the Species column as it is because it doesn't need anything new done to it.
#The following code defines variables ii and jj and uses them to cycle through the rows and columns, respectively, of mytable.  Then it defines entry [ii,jj] of mytable by concatenating the corresponding values of round.avg and round.se, separated by the character string " ± ".
mytable <- round.avg
mytable
for(ii in 1:5){
	for(jj in 2:8){
		mytable[ii,jj] <- paste(round.avg[ii,jj], round.se[ii,jj], sep=" ± ") 
	}
}
mytable

#Save mytable as a csv.
write.csv(mytable, file="My pretty table.csv")

#For some reason when I open this resulting file in Excel, I get the symbol Â before each ±, which seems to be a problem of text encoding between R and Excel but easy to fix in find/change.  Interestingly when I read it back into R it displays correctly again:
mypretty <- read.csv(mytable, file="My pretty table.csv")
mypretty

#Practice with indexing: recreate mytable but with the columns in the following order: Cd.soil, Cd.leaf, Pb.soil, Pb.leaf, Zn.soil, Zn.leaf, AMF

#Practice (more complicated): make a table in the style of mytable, but instead of presenting mean ± SE, present the lower and upper bounds of an approximate 95% confidence interval: mean ± 2*SD.  
#Hint: there are many ways to organize this.  I suggest using aggregate with perhaps one or more homemade functions to calculate the numbers you want to put in the table, and then using a loop as above to arrange the numbers correctly into the table.  
#Note: if you're actually trying to publish a 95% confidence interval you will want to use a more statistically rigorous version!

#Suppose we are interested in the relationships between plant and soil metal concentrations for each species: for instance, is the amount of Zn in the soil under species AA related to the amount of Zn in the leaves of AA?  
#Let's make a table where, for each plant species and each metal studied, we report whether the relationship between plant and soil metal concentrations is positive, negative, or not significant.

#Statistical background: linear regression
#This technique asks whether there is a significant linear relationship between two continuous variables.
#For example, let's look at Zn in species AP

#For the rows of mydata in which Species is AP, run a linear model of Zn.leaf as predicted by Zn.soil
AP.Zn.model <- with(mydata[mydata$Species=="AP",], lm(Zn.leaf~Zn.soil))
#View model summary
summary(AP.Zn.model)
#Regression assumes residuals are normally distributed - here are two ways of checking that.
#A histogram of the residuals should approximate a bell curve
hist(AP.Zn.model$residuals)
#A normal quantile-quantile plot should approximate a 1:1 line.
qqnorm(AP.Zn.model$residuals)

#Does log-transformation help?
apznlog <- with(mydata[mydata$Species=="AP",], lm(log10(Zn.leaf)~log10(Zn.soil)))
summary(apznlog)
hist(apznlog$residuals)
qqnorm(apznlog$residuals)
#Yes, somewhat.  

#From the model summary, we want to pull the parameter estimate (slope of the relationship) to determine whether the relationship is positive or negative, and the P-value to determine whether it is statistically significant.  Let's figure out how to call them.
#Give the summary a shorter, easier name
sz <- summary(apznlog)
#Find the parameter estimate
sz$coefficients[2,1]
#Find the P-value 
sz$coefficients[2,4]

#When we make our table, we'll make the models for each species and metal, extract parameter estimate and P-value from each, and fill in the table based on the results.
#Since we are running many models, we will need to correct for multiple comparisons.  I'll use the Dunn-Sidak correction here but there are many possibilities.
#Find the corrected P-value according to the Dunn-Sidak correction.  We'll make a function to calculate the corrected p-value for n tests at significance level alpha.
dunn.sidak <- function(alpha, n) 1-(1-alpha)^(1/n)
p.corr <- dunn.sidak(0.05, 15)
p.corr

#Practice: Write a function and use it to find the corrected P-value according to a different correction of your choice, such as Bonferroni.

#If/else statements
#Now that we know how to pull these values out of a summary.lm object, let's write a function that produces the entry we want in a given cell in our table: "NS" if the relationship is not statistically significant, and "Positive" or "Negative" for statistically significant relationships based on the parameter estimate.  

#Example of if/else syntax
x <- 5
if(x > 0){
  print("Positive number")
} else {
  print("Not a positive number")
}

#If/else statements can also be useful in functions
myfun1 <- function(p){
	if(p>=p.corr){
		return("NS")
	} else {
		return("SIG")
	}
}

myfun1(0.001)
myfun1(0.003)
myfun1(0.004)
myfun1(0.05)
myfun1(0.8)
myfun1(-10)
myfun1(200)

#The function we want for the table. It takes input values p (assumed to be a p-value) and q (assumed to be a parameter estimate). If p is greater than or equal to the corrected P-value we calculated above (p.corr), it returns "NS" for not significant. If p is less than p.corr, then: if q is positive, it returns "Positive" to indicate a positive relationship, otherwise it returns "Negative" to indicate a negative relationship.
myfun2 <- function(p, q){
	if(p>=p.corr){
		return("NS")
	} else {
		if(q>0){
			return("Positive")
		} else {return("Negative")}
	}
}

#Let's test our function in several scenarios.
myfun2(1,-1)
myfun2(1,0.04)
myfun2(1, 100)
myfun2(0,-1)
myfun2(0,0.05)
myfun2(0,100)
myfun2(0.04, 0.04)

#Practice: what does myfun2 do if p<p.corr and q=0?  How would you handle this situation more sensibly?  Would you ever expect this situation to happen in real life?

#We're getting to the table, I promise!
#Make an empty destination table to store our values
Sp <- c("AA", "AP", "DF", "ES", "MP")
Cd <- rep(NA, 5)
Pb <- rep(NA, 5)
Zn <- rep(NA, 5)
out <- as.data.frame(cbind(Sp, Cd, Pb, Zn))
out

#Get the names of mydata to remind us which numbered columns we need
names(mydata)

#The actual table

out
for(ii in 1:5){ #Loop through the five species
	for(jj in 1:3){ #Loop through the three metals
		model.data <- mydata[mydata$Species==Sp[ii],] #Define dataframe model.data as the rows of mydata where Species is equal to the iith entry of our Sp vector.
		model <- with(model.data, lm(log10(model.data[,jj+3])~log10(model.data[,jj+6]))) #Define the regression model, including log-transformation
		param <- summary(model)$coefficients[2,1] #Extract the parameter estimate from the model summary
		p.val <- summary(model)$coefficients[2,4] #Extract the P-value from the model summary
		out[ii,jj+1] <- myfun2(p.val, param) #Use our function myfun2 to determine the correct entry for cell [ii, jj+1] of out.		
	}
}
out

#The same code without annotation
out
for(ii in 1:5){
	for(jj in 1:3){
		model.data <- mydata[mydata$Species==Sp[ii],]
		model <- with(model.data, lm(log10(model.data[,jj+3])~log10(model.data[,jj+6])))
		param <- summary(model)$coefficients[2,1]
		p.val <- summary(model)$coefficients[2,4]
		out[ii,jj+1] <- myfun2(p.val, param)		
	}
}
out

#Spot-check: do individual model outputs match their entries in the table?
aacd <- with(mydata[mydata$Species=="AA",], lm(log10(Cd.leaf)~log10(Cd.soil)))
summary(aacd)
dfpb <- with(mydata[mydata$Species=="DF",], lm(log10(Pb.leaf)~log10(Pb.soil)))
summary(dfpb)
eszn <- with(mydata[mydata$Species=="ES",], lm(log10(Zn.leaf)~log10(Zn.soil)))
summary(eszn)


#One way of testing the loop: add a line to print one or more values of interest with each iteration of the loop.  This is also useful to check the progress of loops that may be slow to run.
out
for(ii in 1:5){
	for(jj in 1:3){
		model.data <- mydata[mydata$Species==Sp[ii],]
		model <- with(model.data, lm(log10(model.data[,jj+3])~log10(model.data[,jj+6])))
		param <- summary(model)$coefficients[2,1]
		p.val <- summary(model)$coefficients[2,4]
		out[ii,jj+1] <- myfun2(p.val, param)
		print(c(ii, jj, p.val, myfun2(p.val, param)))
		
	}
}
out


#Practice: follow the workflow above to make a table reporting, for each species and each metal, the significance and sign of the relationship between leaf metal concentration and root AMF colonization.  