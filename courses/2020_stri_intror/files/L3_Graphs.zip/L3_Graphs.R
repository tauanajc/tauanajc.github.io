#' ---
#' title: "Tutorial 3 - Graphs"
#' author: "Tauana Cunha"
#' date: "May 2020"
#' ---

#' Plots for data exploration and to carefully design figures for papers and talks
#' basic built-in functions
#' package ggplot2
#' R GALLERY

##########################################' SETUP
#' 
#' Set your working directory:
setwd(dir = "/Users/tauanajc/TEACHING/2020_STRI_introR/L3_Graphs/")

#' More tools are available through packages, sets of new R functions developed by the R community
#' Install ggplot2:
#install.packages("ggrepel")

#' The package is now in your computer and you can delete the installation command from your script
#' Load it to make new functions avalaible:
library(ggplot2)

#' If a package has never been installed, you will get an error trying to load it:
library(vegan)


##########################################' IMPORT AND PREPARE DATASET
#' 
#' Same dataset from Lee's tutorial: leaves, roots, and soils from five plant species growing throughout a site contaminated with the heavy metals zinc, lead and cadmium.
#' Investigate relationships between the metal concentrations in the soil, root colonization by mycorrhizal fungi (AMF), and metal concentrations in the leaves.

#' Read data into heavy_metals object:
heavy_metals <- read.csv(file = "Dietterich et al 2017 data for R course.csv")

#' First few rows and structure:
head(heavy_metals)
str(heavy_metals)

#' To make things more clear for us, let's change the column names:
colnames(heavy_metals) <- c("SampleID", "Species", "Mycorrhizal_Colonization",
                            "Leaves_Cadmium", "Leaves_Lead", "Leaves_Zinc",
                            "Soil_Cadmium", "Soil_Lead", "Soil_Zinc")

head(heavy_metals)

#' Change the species codes, replacing them with the genus name
#' Create a vector with the genus names:
genera <- c("Ageratina", "Deschampsia", "Eupatorium", "Minuartia", "Agrostis")
genera

# Name the elements of this vector according to their code:
names(genera) <- c("AA", "DF", "ES", "MP", "AP")
genera

#' Try indexing the new genera object:
genera[c("AA", "ES")]

# Now let's give it the entire column of species:
genera[heavy_metals$Species]

#' Use the command above to overwrite the content of the column Species:
heavy_metals$Species <- genera[heavy_metals$Species]

#' Check that it worked by looking at some random lines of the dataset:
heavy_metals[c(1,25,50,75,90),1:5]

#' Before plotting, change the Species column from character to factor:
str(heavy_metals)
heavy_metals$Species <- as.factor(heavy_metals$Species)

##########################################' BASIC PLOTS WITH BUILT-IN FUNCTIONS
#' 
#' Some of the most common plot types with built-in functions in R
#' 
#' ##### Histogram
#' Frequencies of values in your data
#' Distribution of the zinc concentrations in the leaves of all plant species:
hist(x = heavy_metals$Leaves_Zinc,
     breaks = 20,
     xlab = "Zinc concentration in plant leaves (mg/kg)",
     main = "")

#' Change axes names to informative names in the code above
#' Much better!
#' 
#' 
#' ##### Boxplot
#' Summarizes data: median, quartiles, minimum and maximum values of the dataset
#' Spacing reflects amount of spread and skewness
#' Boxplot for the same zinc concentrations:
boxplot(x = heavy_metals$Leaves_Zinc,
        ylab = "Zinc concentration in plant leaves (mg/kg)")

boxplot(formula = Leaves_Zinc ~ Species,
        data = heavy_metals,
        ylab = "Zinc concentration in plant leaves (mg/kg)")

#' Add distribution for each one of the individual plant species in the code above
#' 
#' 
#' ##### Scatter plot
#' Relationship between two variables
#' Soil and leaf concentrations of lead:
plot(formula = Leaves_Zinc ~ Soil_Zinc,
     data = heavy_metals,
     ylab = "Zinc concentration in leaves",
     xlab = "Zinc concentration in soil")

#' What about individual plant species?
#' Use a FOR LOOP to get a scatter plot for each of the plants:
for(i in 1:5){
  each_plant = subset(heavy_metals, Species == levels(heavy_metals$Species)[i])
  plot(formula = Leaves_Zinc ~ Soil_Zinc,
       data = each_plant,
       main = levels(heavy_metals$Species)[i],
       ylab = "Zinc concentration in leaves",
       xlab = "Zinc conentration in soil")
}


##########################################' Customization with base R
#' 
#' Many other types of plots and many more options for customization
#' R colors, points, graphic parameters and palettes:
colors()
?points
?par
palette.pals()


##########################################' PANEL WITH 4 DIFFERENT PLOTS: HIST, BOX, SCATTER, and BAR
#' #### Barplot: need mean and error bars
#' Creating function to calculate the standard error - same as last week:
se <- function(x) {
  sd(x)/sqrt(length(x))}

#' Calculate mean of zinc concentrations for each species:
for_barplot <- with(data = heavy_metals,
                    aggregate(formula = Leaves_Zinc ~ Species, FUN = mean))

#' Change column names:
colnames(for_barplot) <- c("Species", "Mean_Zinc")

#' Calculate standard error:
for_barplot$SE_Zinc <- with(data = heavy_metals,
                            aggregate(formula = Leaves_Zinc ~ Species, FUN = se))[,2]

for_barplot

#' Data frame for the colors for each species:
plant_colors <- data.frame(Species = factor(levels(heavy_metals$Species)),
                           Color = c("darkgreen", "darkorange",
                                     "deepskyblue", "firebrick", "darkviolet"),
                           Symbol = c(7,19,24,0,8))

plant_colors

#' ##### PANEL WITH MULTIPLE PLOTS #####
#' #####################################

#' Make 2x2 panel:
par(mfrow = c(2,2))

#' Histogram":
hist(heavy_metals$Soil_Zinc,
     breaks = 20,
     main = "",
     xlab = "Zinc concentration in soil (mg/kg)")

#' Boxplot
boxplot(formula = Leaves_Zinc ~ Species,
        data = heavy_metals,
        col = plant_colors$Color,
        xaxt = "n", # Suppress the x axis completely
        ylab = "Zinc concentration in leaves (mg/kg)",
        xlab = "",
        main = "Boxplots are better than barplots:")

text(x = 1:5, y = -1200, # Position to add labels in x axis
     labels = for_barplot$Species, # Text to add
     xpd = TRUE, # Enable text outside the plot region
     srt = 15) # Angle

mtext(text = "GOOD INFO/INK RATIO",
      side = 3, # Side of the graph
      col = "firebrick",
      cex = .8) # Size of text

# Scatter plot
plot(formula = Mycorrhizal_Colonization*100 ~ Soil_Zinc,
     data = heavy_metals,
     col = palette.colors(n = 5, "Dark 2"),
     pch = plant_colors$Symbol,
     ylab = "Root colonization by fungi (%)",
     xlab = "Zinc concentration in soil (mg/kg)")


mtext(text = "Different color palette just to illustrate",
      side = 4,
      col = "firebrick",
      cex = .8)

# Barplot
barplot(formula = Mean_Zinc ~ Species,
        data = for_barplot,
        col = plant_colors$Color,
        xaxt = "n",
        ylab = "Zinc concentration in leaves (mg/kg)",
        xlab = "",
        ylim = c(0,8000))

text(x = c(0.7,1.9,3.1,4.3,5.5),
     y = -500,
     labels = for_barplot$Species,
     xpd = TRUE,
     srt = 15)

arrows(y0 = for_barplot$Mean_Zinc-for_barplot$SE_Zinc,
       y1 = for_barplot$Mean_Zinc+for_barplot$SE_Zinc,
       x0 = c(0.7,1.9,3.1,4.3,5.5),
       x1 = c(0.7,1.9,3.1,4.3,5.5),
       angle = 90,
       code = 3,
       length = 0.1)

mtext(text = "BAD INFO/INK RATIO",
      side = 3,
      col = "firebrick",
      cex = .8)


par(mfrow = c(1,1)) # Set graphic device back to 1 plot only

#'
#' #####      END OF PANEL        #####
#' #####################################


##########################################' Save basic plots to file
#' Functions like pdf(), png(), tiff(), jpeg()
#' Open an external graphics device to save - not shown in RStudio:
pdf(file = "baseRhist.pdf", width = 5, height = 5)

#' Plot:
hist(heavy_metals$Leaves_Zinc,
     breaks = 20,
     xlab = "Zinc concentration in leaves")

#' Close device:
dev.off()

#' Go back and save the 4-plot panel above


##########################################' ggplot2
#' 
#' Major difference: syntax
#' Layers are put together to create graphs
#' Data should always be in a data frame
#
#' ##### Histogram
#' Basic ggplot command:
ggplot(data = heavy_metals,
       aes(x = Leaves_Zinc)) +
  geom_histogram(na.rm = TRUE,
                 bins = 20) +
  theme_minimal() +
  labs(x = "Zinc concentration in leaves",
       y = "Frequency")

#' Aesthetic (aes): mappings of visual element to a specific variable
#' Specify aesthetics to be used throughout layers (information is inherited):
#'
#' Default themes
#' Labs for axes
#'
#' ##### Boxplot
#' Aesthetics can be also used in the geom_ functions, in which case they are not inherited by other layers:
ggplot(data = heavy_metals) +
  geom_boxplot(aes(y = Leaves_Zinc,
                   x = Species,
                   col = Species,
                   fill = Species),
               na.rm = TRUE,
               alpha = 0.5) +
  theme_minimal() +
  labs(y = "Zinc concentration in leaves") +
  theme(legend.position = "none") +
  scale_fill_brewer(palette = "Dark2") +
  scale_color_brewer(palette = "Dark2")

#' Map color aesthetics above
#' 
#' Fill hides the value of the median
#' Make it transparent in the geom_ function (fixed visual attributes are set outside of aes)
#' Change color schemes with scale_ functions
#' Color Brewer


#' Theme function: legends, fonts of axis, titles, background etc.
#' 
#' Remove legend
#' Italicize names of genera
#' Make them fit better by setting the words at an angle
#' 
#' ##### Scatter plot
#' 
#' Use aesthetics to differentiate points of each Species by color
#' Label specific points of interest with geom_text:
ggpoint <- ggplot(data = heavy_metals,
                  aes(x = Soil_Zinc, y = Leaves_Zinc)) +
  geom_point(aes(fill = Species,
                 col = Species),
             na.rm = TRUE,
             pch = 22,
             size = 3) +
  theme_minimal() +
  labs(x = "Zinc concentration in soil",
       y = "Zinc concentration in leaves") +
  scale_fill_brewer(palette = "Dark2") +
  scale_color_brewer(palette = "Dark2") +
  theme(legend.position = "none")

ggpoint +
  theme_classic()

#' ##### Barplot

# Check online tutorial!

##########################################' Assign ggplots to objects
#'
#' Go back to the four ggplots and assign them to object names: gghist, ggbox, ggpoint, ggbar


#' Add more layers:


#' 
#' 
##########################################' Facet plots
#' 
#' Display several plots of the same kind, each representing a level of a categorical variable
#' Add facets to zinc data, one plot per Species, all in the same figure:
ggpoint +
  facet_wrap(~ Species, nrow = 3)


##########################################' Grid of independent plots
#' 
#' Install and load package cowplot - move this command to top of the script:


#' plot_grid and assign to object metal_plots:



##########################################' Save ggplots to file
#' Save ggplot panel:
ggsave(filename = "ggplot2scatter.pdf",
       plot = ggpoint,
       width = 8,
       height = 8,
       device = "pdf")


##########################################' Exercises!
#' 
#' Practice your skills with plotting on another dataset:
#' your own or the attached dataset about Himalayan Climbing Expeditions (members.csv)
#' 
#' IMPORT AND EXPLORE YOUR DATA:



#' 1. Plot two types of graph (it's ok to try out other types that we did not see together!). Feel free to use built-in functions or ggplot2. The dataset has many interesting variables, many possible questions to explore. There is no correct answer, you can pick and choose basically anything you like. The only rule is that you have to change, in one or both of the graphs, at least the following:
#' 
#' * axes titles
#' * any font element in any part of the plot
#' * color scheme
#' * some element of the legend
#' 
#' PLOT 1:



#' PLOT 2:



#' 2. Now combine these two (or more) plots into one figure:
#' PANEL WITH MULTIPLE PLOTS"



#' 3. Save your plot(s)
#' SAVE: 



#' YOU ARE DONE =)